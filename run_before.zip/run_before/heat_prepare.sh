#!/bin/bash

pip install seaborn
pip install imageio