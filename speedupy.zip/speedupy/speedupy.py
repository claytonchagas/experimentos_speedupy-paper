# speedupy.py — versão final consolidada com suporte completo à Fase 3

import time, sys, os, atexit, hashlib, pickle, argparse
from functools import wraps
sys.path.append(os.path.dirname(__file__))

from execute_exp.services.factory import init_exec_mode, init_revalidation
from execute_exp.services.DataAccess import DataAccess, get_id
from execute_exp.SpeeduPySettings import SpeeduPySettings
from execute_exp.entitites.Metadata import Metadata
from SingletonMeta import SingletonMeta
from util import check_python_version
from logger.log import debug
from speedupy import monitoring

check_python_version()

# Argumentos suportados (agora oficialmente com --monitor-cache)
parser = argparse.ArgumentParser()
parser.add_argument("input", nargs="?")
parser.add_argument("--exec-mode", required=True)
parser.add_argument("--monitor-cache", action="store_true")
parser.add_argument("-s", dest="store_mode")
args, unknown = parser.parse_known_args()

MONITOR = args.monitor_cache
MODE = args.exec_mode
SCRIPT_NAME = os.path.splitext(os.path.basename(sys.argv[0]))[0]
LOG_NAME = f"{SCRIPT_NAME}_{MODE}_cachelog.txt" if MONITOR and MODE else None

# Diretórios
OUTPUT_DIR = "outputs_fase3"
CACHE_DIR = ".speedupy/cache"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Tamanho do cache
def get_cache_size_bytes():
    total = 0
    for root, _, files in os.walk(CACHE_DIR):
        for f in files:
            fp = os.path.join(root, f)
            if os.path.isfile(fp):
                total += os.path.getsize(fp)
    return total

# Registro das métricas ao final
@atexit.register
def dump_cache_metrics():
    if not MONITOR or not LOG_NAME:
        return
    total_access = monitoring.cache_hits + monitoring.cache_misses
    hit_rate = monitoring.cache_hits / total_access if total_access else 0.0
    avg_overhead = monitoring.hit_total_time / monitoring.cache_hits if monitoring.cache_hits else 0.0
    size_bytes = get_cache_size_bytes()
    log_path = os.path.join(OUTPUT_DIR, LOG_NAME)
    with open(log_path, "w") as f:
        f.write(f"cache_entries_created: {monitoring.cache_entries_created}\n")
        f.write(f"cache_hits: {monitoring.cache_hits}\n")
        f.write(f"cache_misses: {monitoring.cache_misses}\n")
        f.write(f"cache_hit_rate: {hit_rate:.4f}\n")
        f.write(f"cache_size_bytes: {size_bytes}\n")
        f.write(f"cache_overhead_per_hit: {avg_overhead:.6f}\n")

# Decorador de funções determinísticas (instrumentado)
def deterministic(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        from speedupy.speedupy_cache import SpeeduPyCache
        key = hashlib.md5(pickle.dumps((func.__name__, args, kwargs))).hexdigest()
        cache = SpeeduPyCache()

        if cache.exists(key):
            start = time.time()
            result = cache.load(key)
            end = time.time()
            if MONITOR:
                monitoring.cache_hits += 1
                monitoring.hit_total_time += (end - start)
            return result
        else:
            result = func(*args, **kwargs)
            cache.save(key, result)
            if MONITOR:
                monitoring.cache_misses += 1
                monitoring.cache_entries_created += 1
            return result
    return wrapper

# Compatibilidade com os modos e inicializações
class SpeeduPy(metaclass=SingletonMeta):
    def __init__(self):
        self.exec_mode = init_exec_mode()
        self.revalidation = init_revalidation(self.exec_mode)

def initialize_speedupy(f):
    @wraps(f)
    def wrapper(*method_args, **method_kwargs):
        start = time.perf_counter()
        DataAccess().init_data_access()
        f(*method_args, **method_kwargs)
        DataAccess().close_data_access()
        end = time.perf_counter()
        print(f"TOTAL EXECUTION TIME: {end - start}")
    return wrapper

def maybe_deterministic(f):
    return f
