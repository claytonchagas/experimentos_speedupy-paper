# monitoring.py — contém os contadores globais para instrumentação

# Contadores globais usados para a Fase 3

cache_hits = 0
cache_misses = 0
cache_entries_created = 0
hit_total_time = 0.0
