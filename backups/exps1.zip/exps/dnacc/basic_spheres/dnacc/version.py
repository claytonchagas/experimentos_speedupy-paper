short_version = '1.1.0'
version = '1.1.0'
full_version = '1.1.0.dev-d5d1fb9'
git_revision = 'd5d1fb9ac21db424eebdd96276888a4258973337'
release = False
if not release:
    version = full_version